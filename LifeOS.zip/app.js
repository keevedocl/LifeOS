let selectedDay = LifeOS.dayIndex();
let taskFilter = "all";

document.addEventListener("DOMContentLoaded", () => {
  updateStreak();
  bindNavigation();
  bindActions();
  applySettings();
  renderAll();
  updateNotificationStatus();
  if ("Notification" in window && Notification.permission === "granted") scheduleNotificationCheck();
});

function bindNavigation() {
  document.querySelectorAll("[data-view]").forEach(btn => btn.addEventListener("click", () => openView(btn.dataset.view)));
}

function openView(viewId) {
  document.querySelectorAll(".view").forEach(v => v.classList.toggle("active", v.id === viewId));
  document.querySelectorAll(".nav-item").forEach(v => v.classList.toggle("active", v.dataset.view === viewId));
  window.scrollTo({top:0,behavior:"smooth"});
}

function bindActions() {
  document.getElementById("addClassButton").onclick = () => openModal("Nueva clase", classForm(), "class");
  document.getElementById("addTaskButton").onclick = () => openModal("Nuevo objetivo", taskForm(), "task");
  document.getElementById("quickTaskButton").onclick = () => openModal("Nuevo objetivo", taskForm(), "task");
  document.getElementById("addRewardButton").onclick = () => openModal("Nueva recompensa", rewardForm(), "reward");
  document.getElementById("closeModal").onclick = closeModal;
  document.getElementById("exportPdfButton").onclick = exportSchedulePDF;
  document.getElementById("notificationButton").onclick = requestNotifications;
  document.getElementById("saveSettingsButton").onclick = saveSettings;
  document.getElementById("resetButton").onclick = resetApp;
  document.getElementById("profileButton").onclick = () => openView("settingsView");

  document.querySelectorAll("[data-task-filter]").forEach(b => b.onclick = () => {
    taskFilter = b.dataset.taskFilter;
    document.querySelectorAll("[data-task-filter]").forEach(x=>x.classList.toggle("active",x===b));
    renderTasks();
  });
}

function renderAll() {
  renderHeader();
  renderXP();
  renderToday();
  renderDayTabs();
  renderSchedule();
  renderTasks();
  renderRewards();
  renderSettings();
}

function renderHeader() {
  const hour = new Date().getHours();
  document.getElementById("greeting").textContent = `${hour < 12 ? "Buenos días" : hour < 19 ? "Buenas tardes" : "Buenas noches"}, ${LifeOS.state.profile.name || "ahí"}`;
  document.getElementById("dateLabel").textContent = new Date().toLocaleDateString("es-CL",{weekday:"long",day:"numeric",month:"long"});
}

function renderXP() {
  const info = levelInfo(LifeOS.state.xp);
  document.getElementById("levelValue").textContent = info.level;
  document.getElementById("xpText").textContent = `${info.current} / ${info.needed} XP`;
  document.getElementById("xpBar").style.width = `${info.current}%`;
  document.getElementById("nextLevelText").textContent = `${info.needed-info.current} XP para el siguiente nivel`;
  document.getElementById("streakValue").textContent = LifeOS.state.streak;
  document.getElementById("rewardBalance").textContent = `${LifeOS.state.xp} XP`;
}

function renderToday() {
  const now = new Date();
  const today = LifeOS.dayIndex(now);
  const items = classesForDay(today);
  const box = document.getElementById("todaySchedule");
  box.innerHTML = items.length ? items.map(c => scheduleCard(c)).join("") : `<div class="empty">No tienes clases programadas hoy.</div>`;
  const tasks = LifeOS.state.tasks.filter(t=>t.date===LifeOS.todayISO());
  document.getElementById("todayTasks").innerHTML = tasks.length ? tasks.map(taskCard).join("") : `<div class="empty">No hay objetivos para hoy. Añade uno y gana XP.</div>`;
  bindDynamicButtons();
}

function scheduleCard(c) {
  return `<div class="card schedule-card"><div class="time">${c.start}<br>${c.end}</div><div><div class="class-title">${escapeHtml(c.title)}</div><div class="meta">${c.room ? `Sala ${escapeHtml(c.room)}` : ""}${c.teacher ? ` · ${escapeHtml(c.teacher)}` : ""}</div></div><span class="class-dot"></span></div>`;
}

function renderDayTabs() {
  document.getElementById("dayTabs").innerHTML = DAYS.map((d,i)=>`<button class="${selectedDay===i?"active":""}" data-day="${i}">${d.slice(0,3)}</button>`).join("");
  document.querySelectorAll("[data-day]").forEach(b=>b.onclick=()=>{selectedDay=Number(b.dataset.day);renderDayTabs();renderSchedule()});
}

function renderSchedule() {
  const items=classesForDay(selectedDay);
  document.getElementById("scheduleList").innerHTML = items.length ? items.map(c=>`
    <div class="card schedule-card" data-edit-class="${c.id}">
      <div class="time">${c.start}<br>${c.end}</div>
      <div><div class="class-title">${escapeHtml(c.title)}</div><div class="meta">${c.room ? `Sala ${escapeHtml(c.room)}` : ""}${c.teacher ? ` · ${escapeHtml(c.teacher)}` : ""} · 🔔 ${formatReminder(Number(c.reminder||LifeOS.state.profile.reminderMinutes))}</div></div>
      <span class="class-dot"></span>
    </div>`).join("") : `<div class="empty">No hay clases este día. Pulsa “+ Clase” para añadir una.</div>`;
  document.querySelectorAll("[data-edit-class]").forEach(el=>el.onclick=()=>editClass(el.dataset.editClass));
}

function renderTasks() {
  let tasks=[...LifeOS.state.tasks];
  if(taskFilter==="pending") tasks=tasks.filter(t=>!t.done);
  if(taskFilter==="done") tasks=tasks.filter(t=>t.done);
  tasks.sort((a,b)=>a.date.localeCompare(b.date)||Number(a.done)-Number(b.done));
  document.getElementById("taskList").innerHTML=tasks.length ? tasks.map(taskCard).join("") : `<div class="empty">No hay objetivos aquí.</div>`;
  bindDynamicButtons();
}

function taskCard(t) {
  return `<div class="card task-card">
    <button class="check ${t.done?"done":""}" data-toggle-task="${t.id}">${t.done?"✓":""}</button>
    <div class="task-main"><div class="task-title ${t.done?"done":""}">${escapeHtml(t.title)}</div><div class="meta">${t.date} · ${t.done?"Completado":"Pendiente"}</div></div>
    <span class="xp-pill">+${t.xp} XP</span>
  </div>`;
}

function renderRewards() {
  const rewards=LifeOS.state.rewards;
  document.getElementById("rewardList").innerHTML=rewards.length ? rewards.map(r=>`
    <div class="reward-card">
      <h3>${escapeHtml(r.title)}</h3><p>${escapeHtml(r.description||"Recompensa personal")}</p>
      <span class="xp-pill">${r.cost} XP</span>
      <button class="primary-button" data-claim-reward="${r.id}" style="margin-top:12px">Canjear</button>
    </div>`).join("") : `<div class="empty" style="grid-column:1/-1">Crea tu primera recompensa.</div>`;
  bindDynamicButtons();
}

function renderSettings() {
  document.getElementById("nameInput").value=LifeOS.state.profile.name||"";
  document.getElementById("reminderInput").value=String(LifeOS.state.profile.reminderMinutes);
  document.getElementById("themeInput").value=LifeOS.state.profile.theme||"midnight";
}

function bindDynamicButtons() {
  document.querySelectorAll("[data-toggle-task]").forEach(b=>b.onclick=()=>toggleTask(b.dataset.toggleTask));
  document.querySelectorAll("[data-claim-reward]").forEach(b=>b.onclick=()=>claimReward(b.dataset.claimReward));
}

function openModal(title, html, type, existing=null) {
  const backdrop=document.getElementById("modalBackdrop");
  document.getElementById("modalTitle").textContent=title;
  const form=document.getElementById("modalForm");
  form.innerHTML=html;
  backdrop.classList.remove("hidden");
  form.onsubmit=(e)=>{e.preventDefault();handleModal(type, form, existing)};
  form.querySelector("[data-close-modal]")?.addEventListener("click",closeModal);
  if(type==="class"&&existing) form.querySelector("#deleteClass")?.addEventListener("click",()=>{LifeOS.state.classes=LifeOS.state.classes.filter(c=>c.id!==existing.id);LifeOS.saveState();closeModal();renderAll();showToast("Clase eliminada")});
}

function closeModal(){document.getElementById("modalBackdrop").classList.add("hidden")}

function handleModal(type, form, existing) {
  const fd=new FormData(form);
  if(type==="class"){
    const data={title:fd.get("title"),day:Number(fd.get("day")),start:fd.get("start"),end:fd.get("end"),room:fd.get("room"),teacher:fd.get("teacher"),reminder:Number(fd.get("reminder"))};
    if(existing) Object.assign(existing,data); else LifeOS.state.classes.push({id:LifeOS.uid("class"),...data});
  }
  if(type==="task"){
    const data={title:fd.get("title"),xp:Number(fd.get("xp")),date:fd.get("date"),done:false};
    if(existing) Object.assign(existing,data); else LifeOS.state.tasks.push({id:LifeOS.uid("task"),...data});
  }
  if(type==="reward"){
    const data={title:fd.get("title"),cost:Number(fd.get("cost")),description:fd.get("description")};
    if(existing) Object.assign(existing,data); else LifeOS.state.rewards.push({id:LifeOS.uid("reward"),...data});
  }
  LifeOS.saveState(); closeModal(); renderAll(); showToast(existing?"Guardado":"Añadido");
}

function editClass(id) {
  const existing=LifeOS.state.classes.find(c=>c.id===id);
  if(existing) openModal("Editar clase",classForm(existing),"class",existing);
}

function toggleTask(id) {
  const t=LifeOS.state.tasks.find(x=>x.id===id);
  if(!t) return;
  if(!t.done){t.done=true;addXP(t.xp,t.title);if(LifeOS.state.streak===0)updateStreak();LifeOS.saveState();}
  else {t.done=false;LifeOS.state.xp=Math.max(0,LifeOS.state.xp-t.xp);LifeOS.saveState();showToast(`-${t.xp} XP · Objetivo reabierto`);}
  renderAll();
}

function claimReward(id) {
  const r=LifeOS.state.rewards.find(x=>x.id===id);
  if(!r) return;
  if(spendXP(r.cost,r.title)){
    LifeOS.state.claimedRewards.push({id:LifeOS.uid("claim"),rewardId:r.id,title:r.title,cost:r.cost,date:LifeOS.todayISO()});
    LifeOS.saveState(); renderAll();
  } else showToast(`Necesitas ${r.cost-LifeOS.state.xp} XP más`);
}

function saveSettings() {
  const name=document.getElementById("nameInput").value.trim()||"Quevedo";
  let reminder=document.getElementById("reminderInput").value;
  if(reminder==="custom"){const n=prompt("¿Cuántos minutos antes?","90");reminder=Number(n)||90}
  LifeOS.state.profile.name=name;
  LifeOS.state.profile.reminderMinutes=Number(reminder);
  LifeOS.state.profile.theme=document.getElementById("themeInput").value;
  LifeOS.saveState(); applySettings(); renderAll(); showToast("Configuración guardada");
}

function applySettings(){document.body.className=`theme-${LifeOS.state.profile.theme||"midnight"}`}

function resetApp(){
  if(!confirm("¿Seguro que quieres borrar todos los datos de LifeOS?")) return;
  LifeOS.resetState(); selectedDay=LifeOS.dayIndex(); renderAll(); applySettings(); showToast("LifeOS restablecido");
}

let toastTimer;
function showToast(message){
  const t=document.getElementById("toast");t.textContent=message;t.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove("show"),2200);
}
