# LifeOS

LifeOS es una PWA personal para organizar horario, objetivos, XP y recompensas.

## Funciones incluidas

- Dashboard con nivel, XP y racha.
- Horario semanal ordenado automáticamente por hora.
- Clases con sala, profesor y recordatorio configurable.
- Objetivos con XP.
- Tienda de recompensas que consume XP.
- Exportación del horario mediante impresión a PDF.
- Temas Midnight, Lavender, Forest y Rose.
- Instalación como PWA.
- Notificaciones web cuando el navegador mantiene la aplicación activa.

## Ejecutarlo

Para que el Service Worker funcione, sirve la carpeta mediante HTTPS o localhost.

En Mac puedes usar Python:

```bash
cd LifeOS
python3 -m http.server 8000
```

Luego abre:

http://localhost:8000

Para instalarlo en un teléfono, el sitio publicado debe estar servido por HTTPS.

## Importante sobre notificaciones

Esta primera versión incluye la base de notificaciones web y solicita permiso al navegador. Los navegadores móviles, especialmente iOS, tienen restricciones sobre ejecución en segundo plano. Para notificaciones realmente fiables incluso cuando LifeOS está cerrado, la siguiente fase debería usar Web Push con un backend.

## GitHub Pages

El proyecto puede publicarse como sitio estático. Para una versión con Web Push, sincronización entre dispositivos y notificaciones programadas en servidor se añadirá un backend en una fase posterior.
