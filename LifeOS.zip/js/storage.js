const STORAGE_KEY = "lifeos_state_v1";

const defaultState = {
  profile: { name: "Quevedo", reminderMinutes: 90, theme: "midnight" },
  xp: 0,
  streak: 0,
  lastActiveDate: null,
  classes: [],
  tasks: [],
  rewards: [],
  claimedRewards: []
};

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return structuredClone(defaultState);
    const parsed = JSON.parse(raw);
    return {
      ...structuredClone(defaultState),
      ...parsed,
      profile: { ...defaultState.profile, ...(parsed.profile || {}) }
    };
  } catch {
    return structuredClone(defaultState);
  }
}

let state = loadState();

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function resetState() {
  state = structuredClone(defaultState);
  saveState();
}

function uid(prefix="id") {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
}

function todayISO() {
  const d = new Date();
  const offset = d.getTimezoneOffset();
  return new Date(d.getTime() - offset * 60000).toISOString().slice(0,10);
}

function dayIndex(date = new Date()) {
  return (date.getDay() + 6) % 7;
}

window.LifeOS = { get state(){ return state; }, saveState, resetState, uid, todayISO, dayIndex };
