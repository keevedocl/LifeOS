const XP_PER_LEVEL = 100;

function levelInfo(xp) {
  const level = Math.floor(xp / XP_PER_LEVEL) + 1;
  const current = xp % XP_PER_LEVEL;
  return { level, current, needed: XP_PER_LEVEL };
}

function addXP(amount, reason = "Acción completada") {
  if (!Number.isFinite(amount) || amount <= 0) return;
  LifeOS.state.xp += Math.round(amount);
  LifeOS.saveState();
  showToast(`+${Math.round(amount)} XP · ${reason}`);
  renderAll();
}

function spendXP(amount, reason = "Recompensa") {
  if (LifeOS.state.xp < amount) return false;
  LifeOS.state.xp -= amount;
  LifeOS.saveState();
  showToast(`-${amount} XP · ${reason}`);
  renderAll();
  return true;
}

function updateStreak() {
  const today = LifeOS.todayISO();
  const last = LifeOS.state.lastActiveDate;
  if (last === today) return;
  if (!last) {
    LifeOS.state.streak = 1;
  } else {
    const a = new Date(last + "T12:00:00");
    const b = new Date(today + "T12:00:00");
    const diff = Math.round((b-a)/86400000);
    LifeOS.state.streak = diff === 1 ? LifeOS.state.streak + 1 : 1;
  }
  LifeOS.state.lastActiveDate = today;
  LifeOS.saveState();
}
