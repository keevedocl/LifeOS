const DAYS = ["Lunes","Martes","Miércoles","Jueves","Viernes","Sábado","Domingo"];

function classSort(a,b){ return a.start.localeCompare(b.start); }

function classesForDay(day) {
  return LifeOS.state.classes.filter(c => Number(c.day) === Number(day)).sort(classSort);
}

function minutesUntil(time) {
  const [h,m] = time.split(":").map(Number);
  const now = new Date();
  const target = new Date();
  target.setHours(h,m,0,0);
  return Math.round((target-now)/60000);
}

function nextClass() {
  const now = new Date();
  const currentDay = LifeOS.dayIndex(now);
  const currentMinutes = now.getHours()*60 + now.getMinutes();
  let candidates = [];
  for (let delta=0; delta<7; delta++) {
    const day = (currentDay+delta)%7;
    classesForDay(day).forEach(c => {
      const [h,m]=c.start.split(":").map(Number);
      const mins=h*60+m;
      if (delta>0 || mins>=currentMinutes) candidates.push({ ...c, delta });
    });
  }
  return candidates[0] || null;
}

function classForm(existing=null) {
  const reminder = existing?.reminder ?? LifeOS.state.profile.reminderMinutes;
  return `
    <div class="form-grid">
      <label>Asignatura<input name="title" required maxlength="60" value="${escapeHtml(existing?.title||"")}" placeholder="Ej. Programación Computacional"></label>
      <div class="two">
        <label>Día<select name="day">${DAYS.map((d,i)=>`<option value="${i}" ${Number(existing?.day??0)===i?"selected":""}>${d}</option>`).join("")}</select></label>
        <label>Sala<input name="room" maxlength="30" value="${escapeHtml(existing?.room||"")}" placeholder="Ej. 204"></label>
      </div>
      <div class="two">
        <label>Inicio<input type="time" name="start" required value="${existing?.start||"08:30"}"></label>
        <label>Término<input type="time" name="end" required value="${existing?.end||"10:40"}"></label>
      </div>
      <label>Profesor<input name="teacher" maxlength="60" value="${escapeHtml(existing?.teacher||"")}" placeholder="Opcional"></label>
      <label>Recordatorio<select name="reminder">
        ${[15,30,60,90,120].map(v=>`<option value="${v}" ${Number(reminder)===v?"selected":""}>${v===60?"1 hora":v===90?"1 hora 30 min":v===120?"2 horas":v+" min"} antes</option>`).join("")}
      </select></label>
      <div class="form-actions">
        <button type="button" class="secondary-button" data-close-modal>Cancelar</button>
        ${existing?'<button type="button" class="danger-button" id="deleteClass">Eliminar</button>':""}
        <button class="primary-button" type="submit">${existing?"Guardar":"Añadir"}</button>
      </div>
    </div>`;
}

function taskForm(existing=null) {
  return `
    <div class="form-grid">
      <label>Objetivo<input name="title" required maxlength="80" value="${escapeHtml(existing?.title||"")}" placeholder="Ej. Estudiar C durante 30 minutos"></label>
      <div class="two">
        <label>XP<input name="xp" type="number" min="1" max="10000" value="${existing?.xp||50}"></label>
        <label>Fecha<input name="date" type="date" value="${existing?.date||LifeOS.todayISO()}"></label>
      </div>
      <div class="form-actions">
        <button type="button" class="secondary-button" data-close-modal>Cancelar</button>
        <button class="primary-button" type="submit">${existing?"Guardar":"Crear"}</button>
      </div>
    </div>`;
}

function rewardForm(existing=null) {
  return `
    <div class="form-grid">
      <label>Recompensa<input name="title" required maxlength="60" value="${escapeHtml(existing?.title||"")}" placeholder="Ej. Noche de película"></label>
      <label>Costo en XP<input name="cost" type="number" min="1" max="100000" value="${existing?.cost||500}"></label>
      <label>Descripción<input name="description" maxlength="100" value="${escapeHtml(existing?.description||"")}" placeholder="Algo que te motive"></label>
      <div class="form-actions">
        <button type="button" class="secondary-button" data-close-modal>Cancelar</button>
        <button class="primary-button" type="submit">${existing?"Guardar":"Crear"}</button>
      </div>
    </div>`;
}

function escapeHtml(value="") {
  return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}
