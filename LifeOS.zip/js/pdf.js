function exportSchedulePDF() {
  const popup = window.open("", "_blank");
  if (!popup) {
    showToast("Permite ventanas emergentes para exportar el PDF");
    return;
  }
  const rows = DAYS.map((day, i) => {
    const items = classesForDay(i);
    return `<section class="day"><h2>${day}</h2>${items.length ? items.map(c => `
      <div class="class">
        <div class="time">${c.start} — ${c.end}</div>
        <div><strong>${escapeHtml(c.title)}</strong><span>${c.room ? `Sala ${escapeHtml(c.room)}` : ""}${c.teacher ? ` · ${escapeHtml(c.teacher)}` : ""}</span></div>
      </div>`).join("") : `<p class="empty">Sin clases</p>`}</section>`;
  }).join("");
  popup.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>LifeOS · Horario</title>
  <style>
  *{box-sizing:border-box}body{font-family:-apple-system,BlinkMacSystemFont,Arial,sans-serif;margin:0;padding:40px;color:#14151a;background:white}
  h1{font-size:30px;margin:0}.sub{color:#777;margin:5px 0 30px}.day{break-inside:avoid;margin-bottom:22px;border:1px solid #ddd;border-radius:16px;padding:15px}
  h2{margin:0 0 10px;font-size:17px}.class{display:grid;grid-template-columns:120px 1fr;gap:16px;padding:12px 0;border-top:1px solid #eee}
  .class:first-of-type{border-top:0}.time{font-weight:700;color:#555}.class span{display:block;color:#777;font-size:12px;margin-top:4px}.empty{color:#999}
  @media print{body{padding:18mm}.day{border:1px solid #ccc}}
  </style></head><body><h1>LIFEOS</h1><div class="sub">Horario semanal · ${new Date().toLocaleDateString("es-CL")}</div>${rows}
  <script>window.onload=()=>window.print()<\/script></body></html>`);
  popup.document.close();
}
