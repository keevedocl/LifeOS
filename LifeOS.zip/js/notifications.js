let notificationTimer = null;

async function requestNotifications() {
  if (!("Notification" in window)) {
    showToast("Este navegador no admite notificaciones web");
    return false;
  }
  const permission = await Notification.requestPermission();
  updateNotificationStatus();
  if (permission === "granted") {
    showToast("Notificaciones activadas");
    scheduleNotificationCheck();
    return true;
  }
  showToast("Permiso de notificaciones no concedido");
  return false;
}

function updateNotificationStatus() {
  const el = document.getElementById("notificationStatus");
  if (!el) return;
  if (!("Notification" in window)) el.textContent = "Este navegador no ofrece notificaciones.";
  else el.textContent = `Estado: ${Notification.permission}`;
}

function scheduleNotificationCheck() {
  clearInterval(notificationTimer);
  notificationTimer = setInterval(checkClassNotifications, 30000);
  checkClassNotifications();
}

function checkClassNotifications() {
  if (!("Notification" in window) || Notification.permission !== "granted") return;
  const now = new Date();
  const today = LifeOS.dayIndex(now);
  const current = now.getHours()*60 + now.getMinutes();
  LifeOS.state.classes.filter(c => Number(c.day) === today).forEach(c => {
    const [h,m] = c.start.split(":").map(Number);
    const classMinutes = h*60+m;
    const reminder = Number(c.reminder ?? LifeOS.state.profile.reminderMinutes);
    if (current === classMinutes-reminder) {
      const key = `${LifeOS.todayISO()}_${c.id}_${reminder}`;
      const sent = JSON.parse(localStorage.getItem("lifeos_notifications") || "{}");
      if (!sent[key]) {
        new Notification("LifeOS · Próxima clase", {
          body: `${c.title} comienza a las ${c.start}. Faltan ${formatReminder(reminder)}.${c.room ? ` Sala ${c.room}.` : ""}`,
          icon: "icons/icon-192.png",
          tag: key
        });
        sent[key] = Date.now();
        localStorage.setItem("lifeos_notifications", JSON.stringify(sent));
      }
    }
  });
}

function formatReminder(mins) {
  if (mins < 60) return `${mins} min`;
  const h = Math.floor(mins/60), m = mins%60;
  return m ? `${h} h ${m} min` : `${h} h`;
}
